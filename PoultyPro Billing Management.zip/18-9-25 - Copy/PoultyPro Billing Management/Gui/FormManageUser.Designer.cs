﻿namespace PoultyPro_Billing_Management.Gui
{
    partial class FormManageUser_s
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormManageUser_s));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.PanalUserManagmentControl = new System.Windows.Forms.Panel();
            this.btnClearSelection = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btmUserShowAll = new System.Windows.Forms.Button();
            this.btmUserRemove = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btmUserAddUser = new System.Windows.Forms.Button();
            this.dgvAdmin = new System.Windows.Forms.DataGridView();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.full_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.username = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.role_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mobile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.created_date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.is_active = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.tableLayoutPanel1.SuspendLayout();
            this.PanalUserManagmentControl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAdmin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 1239F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.PanalUserManagmentControl, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.dgvAdmin, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.dataGridView1, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.87842F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90.12158F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1239, 687);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // PanalUserManagmentControl
            // 
            this.PanalUserManagmentControl.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.PanalUserManagmentControl.Controls.Add(this.btnClearSelection);
            this.PanalUserManagmentControl.Controls.Add(this.txtSearch);
            this.PanalUserManagmentControl.Controls.Add(this.btmUserShowAll);
            this.PanalUserManagmentControl.Controls.Add(this.btmUserRemove);
            this.PanalUserManagmentControl.Controls.Add(this.btnSearch);
            this.PanalUserManagmentControl.Controls.Add(this.btmUserAddUser);
            this.PanalUserManagmentControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanalUserManagmentControl.Location = new System.Drawing.Point(3, 3);
            this.PanalUserManagmentControl.Name = "PanalUserManagmentControl";
            this.PanalUserManagmentControl.Size = new System.Drawing.Size(1233, 59);
            this.PanalUserManagmentControl.TabIndex = 20;
            // 
            // btnClearSelection
            // 
            this.btnClearSelection.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnClearSelection.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearSelection.Location = new System.Drawing.Point(639, 11);
            this.btnClearSelection.Name = "btnClearSelection";
            this.btnClearSelection.Size = new System.Drawing.Size(95, 39);
            this.btnClearSelection.TabIndex = 31;
            this.btnClearSelection.Text = "Clear Selection";
            this.btnClearSelection.UseVisualStyleBackColor = true;
            this.btnClearSelection.Click += new System.EventHandler(this.btnClearSelection_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearch.Location = new System.Drawing.Point(781, 9);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(217, 38);
            this.txtSearch.TabIndex = 5;
            // 
            // btmUserShowAll
            // 
            this.btmUserShowAll.BackColor = System.Drawing.Color.Transparent;
            this.btmUserShowAll.FlatAppearance.BorderSize = 0;
            this.btmUserShowAll.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btmUserShowAll.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.btmUserShowAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btmUserShowAll.Font = new System.Drawing.Font("Times New Roman", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmUserShowAll.ForeColor = System.Drawing.Color.Black;
            this.btmUserShowAll.Image = ((System.Drawing.Image)(resources.GetObject("btmUserShowAll.Image")));
            this.btmUserShowAll.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btmUserShowAll.Location = new System.Drawing.Point(460, 5);
            this.btmUserShowAll.Name = "btmUserShowAll";
            this.btmUserShowAll.Size = new System.Drawing.Size(173, 45);
            this.btmUserShowAll.TabIndex = 4;
            this.btmUserShowAll.Text = "ShowAll";
            this.btmUserShowAll.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btmUserShowAll.UseVisualStyleBackColor = false;
            this.btmUserShowAll.Click += new System.EventHandler(this.btmUserShowAll_Click);
            // 
            // btmUserRemove
            // 
            this.btmUserRemove.BackColor = System.Drawing.Color.Transparent;
            this.btmUserRemove.FlatAppearance.BorderSize = 0;
            this.btmUserRemove.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btmUserRemove.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.btmUserRemove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btmUserRemove.Font = new System.Drawing.Font("Times New Roman", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmUserRemove.ForeColor = System.Drawing.Color.Black;
            this.btmUserRemove.Image = ((System.Drawing.Image)(resources.GetObject("btmUserRemove.Image")));
            this.btmUserRemove.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btmUserRemove.Location = new System.Drawing.Point(222, 8);
            this.btmUserRemove.Name = "btmUserRemove";
            this.btmUserRemove.Size = new System.Drawing.Size(153, 42);
            this.btmUserRemove.TabIndex = 4;
            this.btmUserRemove.Text = "Remove ";
            this.btmUserRemove.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btmUserRemove.UseVisualStyleBackColor = false;
            this.btmUserRemove.Click += new System.EventHandler(this.btmUserRemove_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.Transparent;
            this.btnSearch.FlatAppearance.BorderSize = 0;
            this.btnSearch.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSearch.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearch.Font = new System.Drawing.Font("Segoe UI Black", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.ForeColor = System.Drawing.Color.Black;
            this.btnSearch.Image = ((System.Drawing.Image)(resources.GetObject("btnSearch.Image")));
            this.btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSearch.Location = new System.Drawing.Point(1004, 5);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(199, 49);
            this.btnSearch.TabIndex = 4;
            this.btnSearch.Text = "SearchName";
            this.btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSearch.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btmUserAddUser
            // 
            this.btmUserAddUser.BackColor = System.Drawing.Color.Transparent;
            this.btmUserAddUser.FlatAppearance.BorderSize = 0;
            this.btmUserAddUser.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btmUserAddUser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.btmUserAddUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btmUserAddUser.Font = new System.Drawing.Font("Times New Roman", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmUserAddUser.ForeColor = System.Drawing.Color.Black;
            this.btmUserAddUser.Image = ((System.Drawing.Image)(resources.GetObject("btmUserAddUser.Image")));
            this.btmUserAddUser.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btmUserAddUser.Location = new System.Drawing.Point(24, 5);
            this.btmUserAddUser.Name = "btmUserAddUser";
            this.btmUserAddUser.Size = new System.Drawing.Size(142, 42);
            this.btmUserAddUser.TabIndex = 4;
            this.btmUserAddUser.Text = "Add";
            this.btmUserAddUser.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btmUserAddUser.UseVisualStyleBackColor = false;
            this.btmUserAddUser.Click += new System.EventHandler(this.btmUserAddUser_Click);
            // 
            // dgvAdmin
            // 
            this.dgvAdmin.AllowUserToAddRows = false;
            this.dgvAdmin.AllowUserToDeleteRows = false;
            this.dgvAdmin.BackgroundColor = System.Drawing.Color.White;
            this.dgvAdmin.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvAdmin.ColumnHeadersHeight = 25;
            this.dgvAdmin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvAdmin.Location = new System.Drawing.Point(3, 669);
            this.dgvAdmin.Name = "dgvAdmin";
            this.dgvAdmin.ReadOnly = true;
            this.dgvAdmin.RowHeadersWidth = 51;
            this.dgvAdmin.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAdmin.Size = new System.Drawing.Size(1233, 15);
            this.dgvAdmin.TabIndex = 19;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.ColumnHeadersHeight = 25;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.full_name,
            this.email,
            this.username,
            this.role_id,
            this.mobile,
            this.nid,
            this.address,
            this.created_date,
            this.is_active});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 68);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1233, 595);
            this.dataGridView1.TabIndex = 21;
            this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            // 
            // id
            // 
            this.id.DataPropertyName = "id";
            this.id.HeaderText = "Id";
            this.id.MinimumWidth = 6;
            this.id.Name = "id";
            this.id.ReadOnly = true;
            this.id.Width = 40;
            // 
            // full_name
            // 
            this.full_name.DataPropertyName = "full_name";
            this.full_name.HeaderText = "Full name";
            this.full_name.MinimumWidth = 6;
            this.full_name.Name = "full_name";
            this.full_name.ReadOnly = true;
            this.full_name.Width = 125;
            // 
            // email
            // 
            this.email.DataPropertyName = "email";
            this.email.HeaderText = "Email";
            this.email.MinimumWidth = 6;
            this.email.Name = "email";
            this.email.ReadOnly = true;
            this.email.Width = 125;
            // 
            // username
            // 
            this.username.DataPropertyName = "username";
            this.username.HeaderText = "Username";
            this.username.MinimumWidth = 6;
            this.username.Name = "username";
            this.username.ReadOnly = true;
            this.username.Width = 125;
            // 
            // role_id
            // 
            this.role_id.DataPropertyName = "role_name";
            this.role_id.HeaderText = "Role";
            this.role_id.MinimumWidth = 6;
            this.role_id.Name = "role_id";
            this.role_id.ReadOnly = true;
            this.role_id.Width = 125;
            // 
            // mobile
            // 
            this.mobile.DataPropertyName = "mobile";
            this.mobile.HeaderText = "Mobile";
            this.mobile.MinimumWidth = 6;
            this.mobile.Name = "mobile";
            this.mobile.ReadOnly = true;
            this.mobile.Width = 125;
            // 
            // nid
            // 
            this.nid.DataPropertyName = "nid";
            this.nid.HeaderText = "Nid";
            this.nid.MinimumWidth = 6;
            this.nid.Name = "nid";
            this.nid.ReadOnly = true;
            this.nid.Width = 125;
            // 
            // address
            // 
            this.address.DataPropertyName = "address";
            this.address.HeaderText = "Address";
            this.address.MinimumWidth = 6;
            this.address.Name = "address";
            this.address.ReadOnly = true;
            this.address.Width = 140;
            // 
            // created_date
            // 
            this.created_date.DataPropertyName = "created_date";
            this.created_date.HeaderText = "Joining";
            this.created_date.MinimumWidth = 6;
            this.created_date.Name = "created_date";
            this.created_date.ReadOnly = true;
            this.created_date.Width = 125;
            // 
            // is_active
            // 
            this.is_active.DataPropertyName = "is_active";
            this.is_active.HeaderText = "Status";
            this.is_active.MinimumWidth = 6;
            this.is_active.Name = "is_active";
            this.is_active.ReadOnly = true;
            this.is_active.Width = 125;
            // 
            // FormManageUser_s
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "FormManageUser_s";
            this.Size = new System.Drawing.Size(1239, 687);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.PanalUserManagmentControl.ResumeLayout(false);
            this.PanalUserManagmentControl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAdmin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel PanalUserManagmentControl;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DataGridView dgvAdmin;
        private System.Windows.Forms.Button btmUserShowAll;
        private System.Windows.Forms.Button btmUserRemove;
        private System.Windows.Forms.Button btmUserAddUser;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn full_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn email;
        private System.Windows.Forms.DataGridViewTextBoxColumn username;
        private System.Windows.Forms.DataGridViewTextBoxColumn role_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn mobile;
        private System.Windows.Forms.DataGridViewTextBoxColumn nid;
        private System.Windows.Forms.DataGridViewTextBoxColumn address;
        private System.Windows.Forms.DataGridViewTextBoxColumn created_date;
        private System.Windows.Forms.DataGridViewCheckBoxColumn is_active;
        private System.Windows.Forms.Button btnClearSelection;
    }
}
