﻿using PoultyPro_Billing_Management.DataBase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PoultyPro_Billing_Management.Gui
{
    public partial class FormManageProducts : UserControl
    {
        public DbConnections DbConnections { get; set; }
        public FormManageProducts()
        {
            InitializeComponent();

            try
            {
                
                this.DbConnections = new DbConnections();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to initialize database connection: {ex.Message}",
                               "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //public FormManageProducts(DbConnections dbConnections) : this()
        //{
        //    this.DbConnections = dbConnections;
        //}

        private void btmAddProduct_Click_1(object sender, EventArgs e)
        {
            //FormAddProduct frm = new FormAddProduct();
            //frm.Show();
            try
            {
                if (this.dgvProduct.SelectedRows.Count < 1)
                {
                    FormAddProduct formAddProduct = new FormAddProduct(DbConnections, this, -1);
                    formAddProduct.Show();
                }
                else if (this.dgvProduct.SelectedRows.Count == 1)
                {
                    //FormAddProduct formAddProduct = new FormAddProduct(DbAccess, this, this.dgvProduct.CurrentRow.Cells["id"].Value);
                    FormAddProduct formAddProduct = new FormAddProduct(DbConnections, this, Convert.ToInt32(this.dgvProduct.CurrentRow.Cells["id"].Value));
                    formAddProduct.Show();
                }
                else
                {
                    MessageBox.Show("Please select one row.", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Please try again to add row." + ex.Message, "Alert", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }

        }


        internal void PopulateGridView()
        {
            if (this.DbConnections == null)
            {
                MessageBox.Show("Database access object is not initialized.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            try
            {
                string sql = "select * from product;";
                var ds = this.DbConnections.ExecuteQuery(sql);
                this.dgvProduct.AutoGenerateColumns = false;

                if (ds != null && ds.Tables.Count > 0)
                {
                    this.dgvProduct.DataSource = ds.Tables[0];
                }
                else
                {
                    this.dgvProduct.DataSource = null;
                }

                this.dgvProduct.ClearSelection();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error populating grid: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            



        }

        private void btmUserShowAll_Click(object sender, EventArgs e)
        {
            this.txtSearchproduct.Text = "";
            this.PopulateGridView();
        }

        private void btnSearchProduct_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtSearchproduct.Text))
            {
                PopulateGridView();
                return;
            }

            if (this.DbConnections == null)
            {
                MessageBox.Show("Database access not initialized.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                string searchName = txtSearchproduct.Text.Replace("'", "''");
                string sql = $"SELECT * FROM product WHERE name LIKE '%{searchName}%'";
                var ds = this.DbConnections.ExecuteQuery(sql);
                this.dgvProduct.AutoGenerateColumns = false;

                if (ds != null && ds.Tables.Count > 0)
                {
                    this.dgvProduct.DataSource = ds.Tables[0];
                }
                else
                {
                    this.dgvProduct.DataSource = null;
                    MessageBox.Show("No products found matching the search criteria.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                this.dgvProduct.ClearSelection();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error searching products: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btmUserRemove_Click(object sender, EventArgs e)
        {

            try
            {
                if (this.dgvProduct.SelectedRows.Count < 1)
                {
                    MessageBox.Show("Please select a row first to delete.", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                var productId = this.dgvProduct.CurrentRow.Cells["Id"].Value.ToString();
                var productName = this.dgvProduct.CurrentRow.Cells["name"].Value.ToString();

                var result = MessageBox.Show($"Are you sure you want to delete product '{productName}'?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                if (result == DialogResult.No)
                    return;

                string sql = "DELETE FROM product WHERE Id = '" + productId.Replace("'", "''") + "';";
                var count = this.DbConnections.ExecuteDMLQuery(sql);

                if (count == 1)
                {
                    MessageBox.Show(productName.ToUpper() + " has been removed from the list.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Failed to delete product. Data hasn't been deleted from the list.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                this.PopulateGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while trying to delete the row: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
    }

