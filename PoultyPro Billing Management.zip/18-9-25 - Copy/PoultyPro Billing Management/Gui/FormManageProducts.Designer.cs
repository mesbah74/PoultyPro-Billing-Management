﻿namespace PoultyPro_Billing_Management.Gui
{
    partial class FormManageProducts
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormManageProducts));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.PanalUserManagmentControl = new System.Windows.Forms.Panel();
            this.txtSearchproduct = new System.Windows.Forms.TextBox();
            this.btmUserShowAll = new System.Windows.Forms.Button();
            this.btmUserRemove = new System.Windows.Forms.Button();
            this.btnSearchProduct = new System.Windows.Forms.Button();
            this.btmAddProduct = new System.Windows.Forms.Button();
            this.dgvProduct = new System.Windows.Forms.DataGridView();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.categoryName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unit_price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLayoutPanel1.SuspendLayout();
            this.PanalUserManagmentControl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProduct)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.White;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.Controls.Add(this.PanalUserManagmentControl, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.dgvProduct, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.536586F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 91.46342F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1356, 656);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // PanalUserManagmentControl
            // 
            this.PanalUserManagmentControl.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.PanalUserManagmentControl.Controls.Add(this.txtSearchproduct);
            this.PanalUserManagmentControl.Controls.Add(this.btmUserShowAll);
            this.PanalUserManagmentControl.Controls.Add(this.btmUserRemove);
            this.PanalUserManagmentControl.Controls.Add(this.btnSearchProduct);
            this.PanalUserManagmentControl.Controls.Add(this.btmAddProduct);
            this.PanalUserManagmentControl.Location = new System.Drawing.Point(3, 3);
            this.PanalUserManagmentControl.Name = "PanalUserManagmentControl";
            this.PanalUserManagmentControl.Size = new System.Drawing.Size(1350, 50);
            this.PanalUserManagmentControl.TabIndex = 28;
            // 
            // txtSearchproduct
            // 
            this.txtSearchproduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchproduct.Location = new System.Drawing.Point(730, 6);
            this.txtSearchproduct.Name = "txtSearchproduct";
            this.txtSearchproduct.Size = new System.Drawing.Size(187, 38);
            this.txtSearchproduct.TabIndex = 5;
            // 
            // btmUserShowAll
            // 
            this.btmUserShowAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btmUserShowAll.FlatAppearance.BorderSize = 0;
            this.btmUserShowAll.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btmUserShowAll.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.btmUserShowAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btmUserShowAll.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmUserShowAll.ForeColor = System.Drawing.Color.Black;
            this.btmUserShowAll.Image = ((System.Drawing.Image)(resources.GetObject("btmUserShowAll.Image")));
            this.btmUserShowAll.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btmUserShowAll.Location = new System.Drawing.Point(440, -1);
            this.btmUserShowAll.Name = "btmUserShowAll";
            this.btmUserShowAll.Size = new System.Drawing.Size(152, 51);
            this.btmUserShowAll.TabIndex = 4;
            this.btmUserShowAll.Text = "ShowAll";
            this.btmUserShowAll.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btmUserShowAll.UseVisualStyleBackColor = false;
            this.btmUserShowAll.Click += new System.EventHandler(this.btmUserShowAll_Click);
            // 
            // btmUserRemove
            // 
            this.btmUserRemove.BackColor = System.Drawing.Color.IndianRed;
            this.btmUserRemove.FlatAppearance.BorderSize = 0;
            this.btmUserRemove.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btmUserRemove.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.btmUserRemove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btmUserRemove.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmUserRemove.ForeColor = System.Drawing.Color.Black;
            this.btmUserRemove.Image = ((System.Drawing.Image)(resources.GetObject("btmUserRemove.Image")));
            this.btmUserRemove.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btmUserRemove.Location = new System.Drawing.Point(237, 2);
            this.btmUserRemove.Name = "btmUserRemove";
            this.btmUserRemove.Size = new System.Drawing.Size(156, 45);
            this.btmUserRemove.TabIndex = 4;
            this.btmUserRemove.Text = "Remove ";
            this.btmUserRemove.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btmUserRemove.UseVisualStyleBackColor = false;
            this.btmUserRemove.Click += new System.EventHandler(this.btmUserRemove_Click);
            // 
            // btnSearchProduct
            // 
            this.btnSearchProduct.BackColor = System.Drawing.Color.Yellow;
            this.btnSearchProduct.FlatAppearance.BorderSize = 0;
            this.btnSearchProduct.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSearchProduct.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.btnSearchProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearchProduct.Font = new System.Drawing.Font("Segoe UI Black", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearchProduct.ForeColor = System.Drawing.Color.Black;
            this.btnSearchProduct.Image = ((System.Drawing.Image)(resources.GetObject("btnSearchProduct.Image")));
            this.btnSearchProduct.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSearchProduct.Location = new System.Drawing.Point(923, 4);
            this.btnSearchProduct.Name = "btnSearchProduct";
            this.btnSearchProduct.Size = new System.Drawing.Size(218, 43);
            this.btnSearchProduct.TabIndex = 4;
            this.btnSearchProduct.Text = "Search By Name";
            this.btnSearchProduct.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSearchProduct.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSearchProduct.UseVisualStyleBackColor = false;
            this.btnSearchProduct.Click += new System.EventHandler(this.btnSearchProduct_Click);
            // 
            // btmAddProduct
            // 
            this.btmAddProduct.BackColor = System.Drawing.Color.Lime;
            this.btmAddProduct.FlatAppearance.BorderSize = 0;
            this.btmAddProduct.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btmAddProduct.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.btmAddProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btmAddProduct.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmAddProduct.ForeColor = System.Drawing.Color.Black;
            this.btmAddProduct.Image = ((System.Drawing.Image)(resources.GetObject("btmAddProduct.Image")));
            this.btmAddProduct.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btmAddProduct.Location = new System.Drawing.Point(17, 1);
            this.btmAddProduct.Name = "btmAddProduct";
            this.btmAddProduct.Size = new System.Drawing.Size(185, 46);
            this.btmAddProduct.TabIndex = 4;
            this.btmAddProduct.Text = "Add/Update";
            this.btmAddProduct.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btmAddProduct.UseVisualStyleBackColor = false;
            this.btmAddProduct.Click += new System.EventHandler(this.btmAddProduct_Click_1);
            // 
            // dgvProduct
            // 
            this.dgvProduct.AllowUserToAddRows = false;
            this.dgvProduct.AllowUserToDeleteRows = false;
            this.dgvProduct.BackgroundColor = System.Drawing.Color.White;
            this.dgvProduct.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvProduct.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvProduct.ColumnHeadersHeight = 25;
            this.dgvProduct.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.name,
            this.quantity,
            this.categoryName,
            this.unit_price});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvProduct.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvProduct.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvProduct.Location = new System.Drawing.Point(3, 59);
            this.dgvProduct.Name = "dgvProduct";
            this.dgvProduct.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvProduct.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvProduct.RowHeadersWidth = 51;
            this.dgvProduct.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvProduct.Size = new System.Drawing.Size(1350, 594);
            this.dgvProduct.TabIndex = 29;
            // 
            // id
            // 
            this.id.DataPropertyName = "id";
            this.id.HeaderText = "Id";
            this.id.MinimumWidth = 6;
            this.id.Name = "id";
            this.id.ReadOnly = true;
            this.id.Width = 125;
            // 
            // name
            // 
            this.name.DataPropertyName = "name";
            this.name.HeaderText = "Name";
            this.name.MinimumWidth = 6;
            this.name.Name = "name";
            this.name.ReadOnly = true;
            this.name.Width = 179;
            // 
            // quantity
            // 
            this.quantity.DataPropertyName = "quantity";
            this.quantity.HeaderText = "Quantity";
            this.quantity.MinimumWidth = 6;
            this.quantity.Name = "quantity";
            this.quantity.ReadOnly = true;
            this.quantity.Width = 125;
            // 
            // categoryName
            // 
            this.categoryName.DataPropertyName = "categoryName";
            this.categoryName.HeaderText = "Category Name";
            this.categoryName.MinimumWidth = 6;
            this.categoryName.Name = "categoryName";
            this.categoryName.ReadOnly = true;
            this.categoryName.Width = 125;
            // 
            // unit_price
            // 
            this.unit_price.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.unit_price.DataPropertyName = "unit_price";
            this.unit_price.HeaderText = "Unit Price";
            this.unit_price.MinimumWidth = 6;
            this.unit_price.Name = "unit_price";
            this.unit_price.ReadOnly = true;
            // 
            // FormManageProducts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "FormManageProducts";
            this.Size = new System.Drawing.Size(1356, 656);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.PanalUserManagmentControl.ResumeLayout(false);
            this.PanalUserManagmentControl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProduct)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel PanalUserManagmentControl;
        private System.Windows.Forms.TextBox txtSearchproduct;
        private System.Windows.Forms.Button btmUserShowAll;
        private System.Windows.Forms.Button btnSearchProduct;
        private System.Windows.Forms.Button btmAddProduct;
        private System.Windows.Forms.DataGridView dgvProduct;
        private System.Windows.Forms.Button btmUserRemove;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn categoryName;
        private System.Windows.Forms.DataGridViewTextBoxColumn unit_price;
    }
}
