﻿namespace PoultyPro_Billing_Management.Gui
{
    partial class FormAddSales
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAddSales));
            this.grbAddProduct = new System.Windows.Forms.GroupBox();
            this.dtpInvoiceDate = new System.Windows.Forms.DateTimePicker();
            this.txtItemTotal = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.nudQuantity = new System.Windows.Forms.TextBox();
            this.txtUnitPrice = new System.Windows.Forms.TextBox();
            this.cmbProduct = new System.Windows.Forms.ComboBox();
            this.btnAddItem = new System.Windows.Forms.Button();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.lblUnitPrice = new System.Windows.Forms.Label();
            this.lblproduct = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.grbInvInfo = new System.Windows.Forms.GroupBox();
            this.btnAddCustomer = new System.Windows.Forms.Button();
            this.cmbCustomer = new System.Windows.Forms.ComboBox();
            this.lblName = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblInvId = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblDescription = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.grbAddedItem = new System.Windows.Forms.GroupBox();
            this.dgvInvoiceItems = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnRemoveItem = new System.Windows.Forms.Button();
            this.grbTotalAmount = new System.Windows.Forms.GroupBox();
            this.lblAvailableStock = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSaveInvoice = new System.Windows.Forms.Button();
            this.lblFinalAmount = new System.Windows.Forms.TextBox();
            this.txtDiscount = new System.Windows.Forms.TextBox();
            this.lblPayable = new System.Windows.Forms.Label();
            this.lblDIscount = new System.Windows.Forms.Label();
            this.lblTotalAmount = new System.Windows.Forms.TextBox();
            this.lblSubTotal = new System.Windows.Forms.Label();
            this.grbAddProduct.SuspendLayout();
            this.panel3.SuspendLayout();
            this.grbInvInfo.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.grbAddedItem.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInvoiceItems)).BeginInit();
            this.panel1.SuspendLayout();
            this.grbTotalAmount.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbAddProduct
            // 
            this.grbAddProduct.Controls.Add(this.dtpInvoiceDate);
            this.grbAddProduct.Controls.Add(this.txtItemTotal);
            this.grbAddProduct.Controls.Add(this.label2);
            this.grbAddProduct.Controls.Add(this.nudQuantity);
            this.grbAddProduct.Controls.Add(this.txtUnitPrice);
            this.grbAddProduct.Controls.Add(this.cmbProduct);
            this.grbAddProduct.Controls.Add(this.btnAddItem);
            this.grbAddProduct.Controls.Add(this.lblTotal);
            this.grbAddProduct.Controls.Add(this.lblQuantity);
            this.grbAddProduct.Controls.Add(this.lblUnitPrice);
            this.grbAddProduct.Controls.Add(this.lblproduct);
            this.grbAddProduct.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbAddProduct.Location = new System.Drawing.Point(15, 150);
            this.grbAddProduct.Name = "grbAddProduct";
            this.grbAddProduct.Size = new System.Drawing.Size(1150, 106);
            this.grbAddProduct.TabIndex = 2;
            this.grbAddProduct.TabStop = false;
            this.grbAddProduct.Text = "Add Product";
            // 
            // dtpInvoiceDate
            // 
            this.dtpInvoiceDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpInvoiceDate.Location = new System.Drawing.Point(775, 0);
            this.dtpInvoiceDate.Margin = new System.Windows.Forms.Padding(4);
            this.dtpInvoiceDate.Name = "dtpInvoiceDate";
            this.dtpInvoiceDate.Size = new System.Drawing.Size(340, 25);
            this.dtpInvoiceDate.TabIndex = 15;
            // 
            // txtItemTotal
            // 
            this.txtItemTotal.Location = new System.Drawing.Point(838, 47);
            this.txtItemTotal.Margin = new System.Windows.Forms.Padding(4);
            this.txtItemTotal.Name = "txtItemTotal";
            this.txtItemTotal.ReadOnly = true;
            this.txtItemTotal.Size = new System.Drawing.Size(159, 25);
            this.txtItemTotal.TabIndex = 19;
            this.txtItemTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(625, 3);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 17);
            this.label2.TabIndex = 14;
            this.label2.Text = "Invoice Date:";
            // 
            // nudQuantity
            // 
            this.nudQuantity.Location = new System.Drawing.Point(638, 47);
            this.nudQuantity.Margin = new System.Windows.Forms.Padding(4);
            this.nudQuantity.MaxLength = 3;
            this.nudQuantity.Name = "nudQuantity";
            this.nudQuantity.Size = new System.Drawing.Size(119, 25);
            this.nudQuantity.TabIndex = 18;
            this.nudQuantity.Text = "0";
            this.nudQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudQuantity.TextChanged += new System.EventHandler(this.nudQuantity_TextChanged);
            // 
            // txtUnitPrice
            // 
            this.txtUnitPrice.Location = new System.Drawing.Point(374, 44);
            this.txtUnitPrice.Margin = new System.Windows.Forms.Padding(4);
            this.txtUnitPrice.Name = "txtUnitPrice";
            this.txtUnitPrice.Size = new System.Drawing.Size(159, 25);
            this.txtUnitPrice.TabIndex = 17;
            this.txtUnitPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtUnitPrice.TextChanged += new System.EventHandler(this.txtUnitPrice_TextChanged);
            // 
            // cmbProduct
            // 
            this.cmbProduct.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbProduct.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProduct.FormattingEnabled = true;
            this.cmbProduct.IntegralHeight = false;
            this.cmbProduct.Location = new System.Drawing.Point(90, 45);
            this.cmbProduct.Margin = new System.Windows.Forms.Padding(4);
            this.cmbProduct.Name = "cmbProduct";
            this.cmbProduct.Size = new System.Drawing.Size(180, 25);
            this.cmbProduct.TabIndex = 16;
            // 
            // btnAddItem
            // 
            this.btnAddItem.BackColor = System.Drawing.Color.DarkKhaki;
            this.btnAddItem.Location = new System.Drawing.Point(1030, 47);
            this.btnAddItem.Name = "btnAddItem";
            this.btnAddItem.Size = new System.Drawing.Size(95, 31);
            this.btnAddItem.TabIndex = 12;
            this.btnAddItem.Text = "Add Item";
            this.btnAddItem.UseVisualStyleBackColor = false;
            this.btnAddItem.Click += new System.EventHandler(this.btnAddItem_Click);
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(775, 47);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(56, 20);
            this.lblTotal.TabIndex = 10;
            this.lblTotal.Text = "Total:";
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantity.Location = new System.Drawing.Point(548, 47);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(83, 20);
            this.lblQuantity.TabIndex = 8;
            this.lblQuantity.Text = "Quantity:";
            // 
            // lblUnitPrice
            // 
            this.lblUnitPrice.AutoSize = true;
            this.lblUnitPrice.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUnitPrice.Location = new System.Drawing.Point(272, 46);
            this.lblUnitPrice.Name = "lblUnitPrice";
            this.lblUnitPrice.Size = new System.Drawing.Size(95, 20);
            this.lblUnitPrice.TabIndex = 6;
            this.lblUnitPrice.Text = "Unit Price:";
            // 
            // lblproduct
            // 
            this.lblproduct.AutoSize = true;
            this.lblproduct.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblproduct.Location = new System.Drawing.Point(6, 46);
            this.lblproduct.Name = "lblproduct";
            this.lblproduct.Size = new System.Drawing.Size(83, 20);
            this.lblproduct.TabIndex = 4;
            this.lblproduct.Text = "Product :";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Goldenrod;
            this.panel3.Controls.Add(this.grbInvInfo);
            this.panel3.Location = new System.Drawing.Point(581, 9);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(548, 135);
            this.panel3.TabIndex = 1;
            // 
            // grbInvInfo
            // 
            this.grbInvInfo.Controls.Add(this.btnAddCustomer);
            this.grbInvInfo.Controls.Add(this.cmbCustomer);
            this.grbInvInfo.Controls.Add(this.lblName);
            this.grbInvInfo.Controls.Add(this.lblDate);
            this.grbInvInfo.Controls.Add(this.lblInvId);
            this.grbInvInfo.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbInvInfo.Location = new System.Drawing.Point(14, 8);
            this.grbInvInfo.Name = "grbInvInfo";
            this.grbInvInfo.Size = new System.Drawing.Size(509, 118);
            this.grbInvInfo.TabIndex = 0;
            this.grbInvInfo.TabStop = false;
            this.grbInvInfo.Text = "Invoice Information";
            // 
            // btnAddCustomer
            // 
            this.btnAddCustomer.Location = new System.Drawing.Point(395, 80);
            this.btnAddCustomer.Margin = new System.Windows.Forms.Padding(4);
            this.btnAddCustomer.Name = "btnAddCustomer";
            this.btnAddCustomer.Size = new System.Drawing.Size(107, 31);
            this.btnAddCustomer.TabIndex = 13;
            this.btnAddCustomer.Text = "Add New";
            this.btnAddCustomer.UseVisualStyleBackColor = true;
            this.btnAddCustomer.Click += new System.EventHandler(this.btnAddCustomer_Click);
            // 
            // cmbCustomer
            // 
            this.cmbCustomer.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbCustomer.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCustomer.FormattingEnabled = true;
            this.cmbCustomer.Location = new System.Drawing.Point(203, 44);
            this.cmbCustomer.Margin = new System.Windows.Forms.Padding(4);
            this.cmbCustomer.Name = "cmbCustomer";
            this.cmbCustomer.Size = new System.Drawing.Size(294, 25);
            this.cmbCustomer.TabIndex = 12;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(52, 47);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(154, 20);
            this.lblName.TabIndex = 8;
            this.lblName.Text = "Customer Name : ";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(298, 20);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(57, 20);
            this.lblDate.TabIndex = 7;
            this.lblDate.Text = "Date :";
            // 
            // lblInvId
            // 
            this.lblInvId.AutoSize = true;
            this.lblInvId.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvId.Location = new System.Drawing.Point(59, 22);
            this.lblInvId.Name = "lblInvId";
            this.lblInvId.Size = new System.Drawing.Size(0, 20);
            this.lblInvId.TabIndex = 6;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Goldenrod;
            this.panel2.Controls.Add(this.lblDescription);
            this.panel2.Controls.Add(this.lblTitle);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Location = new System.Drawing.Point(24, 9);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(529, 134);
            this.panel2.TabIndex = 0;
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescription.Location = new System.Drawing.Point(277, 74);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(234, 20);
            this.lblDescription.TabIndex = 2;
            this.lblDescription.Text = "Billing Management system";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(228, 30);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(144, 29);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "PoultryPro";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Goldenrod;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(24, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(107, 118);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // grbAddedItem
            // 
            this.grbAddedItem.Controls.Add(this.dgvInvoiceItems);
            this.grbAddedItem.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbAddedItem.Location = new System.Drawing.Point(15, 262);
            this.grbAddedItem.Name = "grbAddedItem";
            this.grbAddedItem.Size = new System.Drawing.Size(774, 288);
            this.grbAddedItem.TabIndex = 3;
            this.grbAddedItem.TabStop = false;
            this.grbAddedItem.Text = "Added Item";
            // 
            // dgvInvoiceItems
            // 
            this.dgvInvoiceItems.AllowUserToAddRows = false;
            this.dgvInvoiceItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInvoiceItems.Location = new System.Drawing.Point(6, 24);
            this.dgvInvoiceItems.Name = "dgvInvoiceItems";
            this.dgvInvoiceItems.ReadOnly = true;
            this.dgvInvoiceItems.RowHeadersWidth = 51;
            this.dgvInvoiceItems.RowTemplate.Height = 24;
            this.dgvInvoiceItems.Size = new System.Drawing.Size(762, 265);
            this.dgvInvoiceItems.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Linen;
            this.panel1.Controls.Add(this.btnBack);
            this.panel1.Controls.Add(this.btnClear);
            this.panel1.Controls.Add(this.btnRemoveItem);
            this.panel1.Controls.Add(this.grbTotalAmount);
            this.panel1.Controls.Add(this.grbAddedItem);
            this.panel1.Controls.Add(this.grbAddProduct);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(3, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1176, 642);
            this.panel1.TabIndex = 1;
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.DarkKhaki;
            this.btnBack.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(980, 594);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(183, 28);
            this.btnBack.TabIndex = 27;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.DarkKhaki;
            this.btnClear.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(484, 566);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(183, 28);
            this.btnClear.TabIndex = 26;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnRemoveItem
            // 
            this.btnRemoveItem.BackColor = System.Drawing.Color.DarkKhaki;
            this.btnRemoveItem.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemoveItem.Location = new System.Drawing.Point(270, 566);
            this.btnRemoveItem.Name = "btnRemoveItem";
            this.btnRemoveItem.Size = new System.Drawing.Size(183, 28);
            this.btnRemoveItem.TabIndex = 25;
            this.btnRemoveItem.Text = "Remove Item";
            this.btnRemoveItem.UseVisualStyleBackColor = false;
            this.btnRemoveItem.Click += new System.EventHandler(this.btnRemoveItem_Click);
            // 
            // grbTotalAmount
            // 
            this.grbTotalAmount.Controls.Add(this.lblAvailableStock);
            this.grbTotalAmount.Controls.Add(this.label1);
            this.grbTotalAmount.Controls.Add(this.btnSaveInvoice);
            this.grbTotalAmount.Controls.Add(this.lblFinalAmount);
            this.grbTotalAmount.Controls.Add(this.txtDiscount);
            this.grbTotalAmount.Controls.Add(this.lblPayable);
            this.grbTotalAmount.Controls.Add(this.lblDIscount);
            this.grbTotalAmount.Controls.Add(this.lblTotalAmount);
            this.grbTotalAmount.Controls.Add(this.lblSubTotal);
            this.grbTotalAmount.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbTotalAmount.Location = new System.Drawing.Point(791, 273);
            this.grbTotalAmount.Name = "grbTotalAmount";
            this.grbTotalAmount.Size = new System.Drawing.Size(374, 278);
            this.grbTotalAmount.TabIndex = 4;
            this.grbTotalAmount.TabStop = false;
            this.grbTotalAmount.Text = "Total Amount";
            // 
            // lblAvailableStock
            // 
            this.lblAvailableStock.AutoSize = true;
            this.lblAvailableStock.ForeColor = System.Drawing.Color.Blue;
            this.lblAvailableStock.Location = new System.Drawing.Point(114, 28);
            this.lblAvailableStock.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAvailableStock.Name = "lblAvailableStock";
            this.lblAvailableStock.Size = new System.Drawing.Size(0, 17);
            this.lblAvailableStock.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(187, 131);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 17);
            this.label1.TabIndex = 25;
            // 
            // btnSaveInvoice
            // 
            this.btnSaveInvoice.BackColor = System.Drawing.Color.DarkKhaki;
            this.btnSaveInvoice.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveInvoice.Location = new System.Drawing.Point(118, 238);
            this.btnSaveInvoice.Name = "btnSaveInvoice";
            this.btnSaveInvoice.Size = new System.Drawing.Size(183, 28);
            this.btnSaveInvoice.TabIndex = 23;
            this.btnSaveInvoice.Text = "SaveInvoice";
            this.btnSaveInvoice.UseVisualStyleBackColor = false;
            this.btnSaveInvoice.Click += new System.EventHandler(this.btnSaveInvoice_Click);
            // 
            // lblFinalAmount
            // 
            this.lblFinalAmount.Location = new System.Drawing.Point(130, 169);
            this.lblFinalAmount.Multiline = true;
            this.lblFinalAmount.Name = "lblFinalAmount";
            this.lblFinalAmount.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.lblFinalAmount.Size = new System.Drawing.Size(209, 31);
            this.lblFinalAmount.TabIndex = 22;
            // 
            // txtDiscount
            // 
            this.txtDiscount.Location = new System.Drawing.Point(130, 117);
            this.txtDiscount.Multiline = true;
            this.txtDiscount.Name = "txtDiscount";
            this.txtDiscount.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.txtDiscount.Size = new System.Drawing.Size(209, 31);
            this.txtDiscount.TabIndex = 21;
            this.txtDiscount.TextChanged += new System.EventHandler(this.txtDiscount_TextChanged);
            // 
            // lblPayable
            // 
            this.lblPayable.AutoSize = true;
            this.lblPayable.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPayable.Location = new System.Drawing.Point(5, 176);
            this.lblPayable.Name = "lblPayable";
            this.lblPayable.Size = new System.Drawing.Size(128, 21);
            this.lblPayable.TabIndex = 19;
            this.lblPayable.Text = "Net Payable :";
            // 
            // lblDIscount
            // 
            this.lblDIscount.AutoSize = true;
            this.lblDIscount.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDIscount.Location = new System.Drawing.Point(26, 124);
            this.lblDIscount.Name = "lblDIscount";
            this.lblDIscount.Size = new System.Drawing.Size(99, 21);
            this.lblDIscount.TabIndex = 18;
            this.lblDIscount.Text = "Discount :";
            // 
            // lblTotalAmount
            // 
            this.lblTotalAmount.Location = new System.Drawing.Point(129, 57);
            this.lblTotalAmount.Multiline = true;
            this.lblTotalAmount.Name = "lblTotalAmount";
            this.lblTotalAmount.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.lblTotalAmount.Size = new System.Drawing.Size(209, 31);
            this.lblTotalAmount.TabIndex = 15;
            // 
            // lblSubTotal
            // 
            this.lblSubTotal.AutoSize = true;
            this.lblSubTotal.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubTotal.Location = new System.Drawing.Point(21, 64);
            this.lblSubTotal.Name = "lblSubTotal";
            this.lblSubTotal.Size = new System.Drawing.Size(104, 21);
            this.lblSubTotal.TabIndex = 14;
            this.lblSubTotal.Text = "Sub Total :";
            // 
            // FormAddSales
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1182, 638);
            this.Controls.Add(this.panel1);
            this.Name = "FormAddSales";
            this.Text = "FormAddSales";
            this.Load += new System.EventHandler(this.FormAddSales_Load);
            this.grbAddProduct.ResumeLayout(false);
            this.grbAddProduct.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.grbInvInfo.ResumeLayout(false);
            this.grbInvInfo.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.grbAddedItem.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvInvoiceItems)).EndInit();
            this.panel1.ResumeLayout(false);
            this.grbTotalAmount.ResumeLayout(false);
            this.grbTotalAmount.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbAddProduct;
        private System.Windows.Forms.Button btnAddItem;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.Label lblUnitPrice;
        private System.Windows.Forms.Label lblproduct;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.GroupBox grbInvInfo;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblInvId;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox grbAddedItem;
        private System.Windows.Forms.DataGridView dgvInvoiceItems;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnRemoveItem;
        private System.Windows.Forms.GroupBox grbTotalAmount;
        private System.Windows.Forms.Button btnSaveInvoice;
        private System.Windows.Forms.TextBox lblFinalAmount;
        private System.Windows.Forms.TextBox txtDiscount;
        private System.Windows.Forms.Label lblPayable;
        private System.Windows.Forms.Label lblDIscount;
        private System.Windows.Forms.TextBox lblTotalAmount;
        private System.Windows.Forms.Label lblSubTotal;
        private System.Windows.Forms.TextBox txtItemTotal;
        private System.Windows.Forms.TextBox nudQuantity;
        private System.Windows.Forms.TextBox txtUnitPrice;
        private System.Windows.Forms.ComboBox cmbProduct;
        private System.Windows.Forms.DateTimePicker dtpInvoiceDate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAddCustomer;
        private System.Windows.Forms.ComboBox cmbCustomer;
        private System.Windows.Forms.Label lblAvailableStock;
        private System.Windows.Forms.Label label1;
    }
}