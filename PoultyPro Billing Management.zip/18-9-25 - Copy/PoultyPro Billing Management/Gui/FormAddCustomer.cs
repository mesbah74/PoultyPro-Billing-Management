﻿using PoultyPro_Billing_Management.DataBase;    
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PoultyPro_Billing_Management.Gui

{
    public partial class FormAddCustomer : Form
    {
        public DbConnections DbConnections { get; set; }
        public event EventHandler CustomerAdded;
        public FormAddCustomer()
        {
            InitializeComponent();
            this.DbConnections = new DbConnections();

            this.AutoIdGenerate();

        }
        public FormAddCustomer(DbConnections dbConnections) : this()
        {
            this.DbConnections = dbConnections;
        }
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtName.Text))
                {
                    MessageBox.Show("Please enter customer name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtName.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtMobile.Text))
                {
                    MessageBox.Show("Please enter mobile number.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMobile.Focus();
                    return;
                }

                string name = txtName.Text.Replace("'", "''").Trim();
                string mobile = txtMobile.Text.Replace("'", "''").Trim();

                string sql = $"INSERT INTO customer (name, mobile) VALUES ('{name}', '{mobile}')";
                int result = DbConnections.ExecuteDMLQuery(sql);

                if (result > 0)
                {
                    MessageBox.Show("Customer added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    CustomerAdded?.Invoke(this, EventArgs.Empty);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Failed to add customer.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding customer: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtCustomerId_TextChanged(object sender, EventArgs e)
        {

        }
        private void AutoIdGenerate()
        {

            var query = "SELECT MAX(Id) FROM customer;";
            var dt = this.DbConnections.ExecuteQueryTable(query);

            var oldId = dt.Rows[0][0] == DBNull.Value ? 0 : Convert.ToInt32(dt.Rows[0][0]);
            var newId = oldId + 1;
            this.txtCustomerId.Text = newId.ToString();
            this.txtCustomerId.ReadOnly = true;
        }

        

    }
}
