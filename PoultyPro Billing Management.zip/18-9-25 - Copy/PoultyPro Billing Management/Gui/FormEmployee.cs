﻿using PoultyPro_Billing_Management.DataBase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PoultyPro_Billing_Management.Gui
{
    public partial class FormEmployee : Form
    {
        public bool isLogoutClicked = false;
        public FormLogIn FormLogIn { get; set; }
        public DbConnections DbConnections { get; set; }
        public string Username { get; set; }
        public DataTable DataTable { get; set; }
        private bool isCloseConfirmed = false;
        public FormEmployee()
        {
            InitializeComponent();
        }
        public FormEmployee(DbConnections dbConnections, FormLogIn formLogin, string username) : this()
        {
            this.DbConnections = dbConnections;
            this.FormLogIn = formLogin;
            this.Username = username;
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {

            if (isLogoutClicked || isCloseConfirmed)
            {
                base.OnFormClosing(e);
                return;
            }

            DialogResult result = MessageBox.Show(
             "Are you sure you want to exit?",
             "Exit Application",
             MessageBoxButtons.YesNo,
             MessageBoxIcon.Question,
             MessageBoxDefaultButton.Button2);

            if (result == DialogResult.No)
            {
                e.Cancel = true;
                return;
            }

            isCloseConfirmed = true;
            Application.Exit();

            return;
        }

     

        private void btnAddSales_Click(object sender, EventArgs e)
        {
            //FormAddSales frm = new FormAddSales();
            //frm.Show();

            try
            {
                string sql = "select id from users where username = '" + this.Username + "';";
                DataTable userTable = this.DbConnections.ExecuteQueryTable(sql);

                if (userTable != null && userTable.Rows.Count > 0)
                {
                    int userId = Convert.ToInt32(userTable.Rows[0]["id"]);
                    FormAddSales formAddSale = new FormAddSales(this.DbConnections, userId, this);
                    this.Hide();
                    formAddSale.Show();
                }
                else
                {
                    MessageBox.Show("User not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error opening Add Sale form: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSalesReport_Click(object sender, EventArgs e)
        {
            //FromSalesReport frm = new FromSalesReport();
            //frm.Show();
            try
            {
                FromSalesReport formSalesReport = new FromSalesReport(this.DbConnections, this);
                this.Hide();
                formSalesReport.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error opening Sales Report: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLogOut_Click_1(object sender, EventArgs e)
        {
            //isLogoutClicked = true;

            //if (this.Owner != null && this.Owner is FormLogIn loginForm)
            //{
            //    loginForm.Show();
            //}
            //else
            //{
            //    DialogResult result = MessageBox.Show(
            //        "Are you sure you want to logout?",
            //        "Logout Confirmation",
            //        MessageBoxButtons.YesNo,
            //        MessageBoxIcon.Question);

            //    if (result == DialogResult.Yes)
            //    {

            //        FormLogIn newloginForm = new FormLogIn();
            //        newloginForm.isLogoutClicked = true; 
            //        newloginForm.Show();

            //        this.Hide(); 
            //    }
            //}
            isLogoutClicked = true;

            if (this.Owner != null && this.Owner is FormLogIn loginForm)
            {
                loginForm.Show();

            }
            else
            {
                loginForm = new FormLogIn();
                loginForm.Show();

            }

            this.Close();

        }

        private void btnAddCus_Click(object sender, EventArgs e)
        {
            FormAddCustomer frm = new FormAddCustomer();
            frm.Show();
        }
    }
}
