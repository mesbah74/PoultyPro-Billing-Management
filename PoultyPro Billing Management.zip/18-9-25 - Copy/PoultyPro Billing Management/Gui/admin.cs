﻿using PoultyPro_Billing_Management.DataBase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PoultyPro_Billing_Management.Gui
{

    public partial class admin : Form
    {

      
        public bool isLogoutClicked = false;

        private bool isCloseConfirmed = false;

        public FormLogIn FormLogIn { get; set; }
        public DbConnections DbConnections { get; set; }
        public string Username { get; set; }
       // public DataTable DataTable { get; set; }

        public admin()
        {
            InitializeComponent();
        }
        public admin(DbConnections dbConnections, FormLogIn formLogin, string username) : this()
        {
            this.DbConnections = dbConnections;
            this.FormLogIn = formLogin;
            this.Username = username;
        }
        private void btmManageUser_Click(object sender, EventArgs e)
        {
           
            formManageUser_s1.DbConnections = this.DbConnections;
            formManageUser_s1.BringToFront();

        }

        private void btmSellReports_Click(object sender, EventArgs e)
        {

            //FromSalesReport frm = new FromSalesReport();
            //frm.Show();
            try
            {
                FromSalesReport formSalesReport = new FromSalesReport(this.DbConnections, this);
                this.Hide();
                formSalesReport.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error opening Sales Report: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }


        private void buttonLogoutControl_Click(object sender, EventArgs e)
        {

            //// Show Login Form
            //LogIn loginForm = new LogIn();
            //loginForm.Show();

            //this.Hide();
            //// Close current Admin form

            //DialogResult result = MessageBox.Show(
            //"Are you sure you want to logout?",
            //"Logout Confirmation",
            //MessageBoxButtons.YesNo,
            //MessageBoxIcon.Question);

            //     if (result == DialogResult.Yes)
            //     {
            //       
            //         LogIn loginForm = new LogIn();
            //         loginForm.isLogoutClicked = true; 
            //         loginForm.Show();

            //         this.Close(); 
            //     }


            //isLogoutClicked = true;

            // if (this.Owner != null && this.Owner is FormLogIn loginForm)
            // {
            //     loginForm.Show();
            // }
            // else
            // {
            //     DialogResult result = MessageBox.Show(
            //         "Are you sure you want to logout?",
            //         "Logout Confirmation",
            //         MessageBoxButtons.YesNo,
            //         MessageBoxIcon.Question);

            //     if (result == DialogResult.Yes)
            //     {

            //         //FormLogIn newloginForm = new FormLogIn();
            //         //newloginForm.isLogoutClicked = true; 
            //         //newloginForm.Show();

            //         this.Hide(); 
            //     }
            // }
            //this.Close();

            isLogoutClicked = true;

            if (this.Owner != null && this.Owner is FormLogIn loginForm)
            {
                loginForm.Show();

            }
            else
            {
                loginForm = new FormLogIn();
                loginForm.Show();

            }

            this.Close();

        }




        protected override void OnFormClosing(FormClosingEventArgs e)
        {


            if (isLogoutClicked || isCloseConfirmed)
            {
                base.OnFormClosing(e);
                return;
            }

            DialogResult result = MessageBox.Show(
             "Are you sure you want to exit?",
             "Exit Application",
             MessageBoxButtons.YesNo,
             MessageBoxIcon.Question,
             MessageBoxDefaultButton.Button2);

            if (result == DialogResult.No)
            {
                e.Cancel = true;
                return;
            }

            isCloseConfirmed = true;
            Application.Exit();

            return;


        }

        private void btmManageProduct_Click(object sender, EventArgs e)
        {
            formManageProducts1.BringToFront();
        }

      

       
      

        private void admin_Load(object sender, EventArgs e)
        {

            userControlDefault.BringToFront();
        }

        private void btmAddSell_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = "select id from users where username = '" + this.Username + "';";
                DataTable userTable = this.DbConnections.ExecuteQueryTable(sql);

                if (userTable != null && userTable.Rows.Count > 0)
                {
                    int userId = Convert.ToInt32(userTable.Rows[0]["id"]);
                    FormAddSales formAddSale = new FormAddSales(this.DbConnections, userId, this);
                    this.Hide();
                    formAddSale.Show();
                }
                else
                {
                    MessageBox.Show("User not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error opening Add Sale form: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void labelTitleControlDashboard_Click(object sender, EventArgs e)
        {

        }

      
    }
}

