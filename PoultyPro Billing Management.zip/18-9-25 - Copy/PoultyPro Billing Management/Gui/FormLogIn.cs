﻿using PoultyPro_Billing_Management.DataBase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace PoultyPro_Billing_Management.Gui
{
    public partial class FormLogIn : Form
    {
        public DbConnections DbConnections { get; set; }
        public string LoggedInUser { get; private set; }

        public bool isLogoutClicked = false;

        private bool isCloseConfirmed = false;

        public FormLogIn()
        {
            InitializeComponent();

            try
            {
                this.DbConnections = new DbConnections();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error has occurred in opening the database system, please try again.\n" + ex.Message);
            }
        }







        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
               
                if (string.IsNullOrWhiteSpace(txtUserName.Text))
                {
                    MessageBox.Show("Please enter a username.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtUserName.Focus();
                    return;
                }

                
                if (string.IsNullOrWhiteSpace(txtPassword.Text))
                {
                    MessageBox.Show("Please enter a password.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtPassword.Focus();
                    return;
                }

                string username = txtUserName.Text.Trim();
                string password = txtPassword.Text;

               
                string sql = @"SELECT u.id, u.username, u.password, u.full_name, r.role_name, u.is_active 
                       FROM users u 
                       INNER JOIN role r ON u.role_id = r.id 
                       WHERE u.username = '" + username.Replace("'", "''") + "' " +
                               "AND u.password = '" + password.Replace("'", "''") + "' " +
                               "AND r.role_name IN ('Admin', 'Employee') " +
                               "AND u.is_active = 1";

                var dataTable = DbConnections.ExecuteQueryTable(sql);

                if (dataTable != null && dataTable.Rows.Count == 1)
                {
                    var row = dataTable.Rows[0];
                    string roleName = row["role_name"].ToString();
                    string fullName = row["full_name"].ToString();

                    if (roleName.Equals("Admin", StringComparison.OrdinalIgnoreCase))
                    {
                        MessageBox.Show($"Welcome {fullName}!\nLogin successful as Administrator.", "Login Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        admin formAdmin = new admin(DbConnections, this, username);
                        formAdmin.Owner = this;
                        formAdmin.FormClosed += (s, args) =>
                        {
                            this.Show();
                        };

                        formAdmin.Show();
                        this.Hide();
                        txtUserName.Clear();
                        txtPassword.Clear();
                    }
                    else if (roleName.Equals("Employee", StringComparison.OrdinalIgnoreCase))
                    {
                        MessageBox.Show($"Welcome {fullName}!\nLogin successful as Employee.", "Login Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        FormEmployee formEmployee = new FormEmployee(DbConnections, this, username);
                        formEmployee.Owner = this;
                        formEmployee.FormClosed += (s, args) =>
                        {
                            this.Show();
                        };
                        formEmployee.Show();
                        this.Hide();
                        txtUserName.Clear();
                        txtPassword.Clear();
                    }
                }
                else
                {
                   
                    MessageBox.Show("Invalid username or password. Please try again.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtPassword.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        //private void FormLogin_FormClosing(object sender, FormClosingEventArgs e)
        //{
        //    try
        //    {
        //        this.Close();
        //        this.DbConnections.CloseConnection();
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("An error has occurred in closing system.\n" + ex.Message);
        //    }
        //}

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtUserName.Clear();
            txtPassword.Clear();
            txtUserName.Focus();
        }

        private void checkBoxPassShow_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxPassShow.Checked)
            {
                
                txtPassword.PasswordChar = '\0';
            }
            else
            {
             
                txtPassword.PasswordChar = '*';
            }
        }

        private void FormLogIn_Load(object sender, EventArgs e)
        {

        }
    }
    }


    

