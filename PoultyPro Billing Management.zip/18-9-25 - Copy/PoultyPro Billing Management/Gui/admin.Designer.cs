﻿namespace PoultyPro_Billing_Management.Gui
{
    partial class admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(admin));
            PoultyPro_Billing_Management.DataBase.DbConnections dbConnections1 = new PoultyPro_Billing_Management.DataBase.DbConnections();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panelTitleNameAdmin = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.labelTitleControlDashboard = new System.Windows.Forms.Label();
            this.panelTopLabelControl = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelAdminDevDashboard = new System.Windows.Forms.Label();
            this.panelSlidebarControl = new System.Windows.Forms.Panel();
            this.buttonLogoutControl = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btmSellReports = new System.Windows.Forms.Button();
            this.btmAddSell = new System.Windows.Forms.Button();
            this.btmManageProduct = new System.Windows.Forms.Button();
            this.btmManageUser = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelDisplayAdmin = new System.Windows.Forms.Panel();
            this.formManageProducts1 = new PoultyPro_Billing_Management.Gui.FormManageProducts();
            this.userControlDefault = new PoultyPro_Billing_Management.Gui.UserControlDefaultcs();
            this.formManageUser_s1 = new PoultyPro_Billing_Management.Gui.FormManageUser_s();
            this.tableLayoutPanel1.SuspendLayout();
            this.panelTitleNameAdmin.SuspendLayout();
            this.panelTopLabelControl.SuspendLayout();
            this.panelSlidebarControl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelDisplayAdmin.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.White;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 306F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.panelTitleNameAdmin, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panelTopLabelControl, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panelSlidebarControl, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panelDisplayAdmin, 1, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 89F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1625, 753);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panelTitleNameAdmin
            // 
            this.panelTitleNameAdmin.BackColor = System.Drawing.Color.SandyBrown;
            this.panelTitleNameAdmin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelTitleNameAdmin.Controls.Add(this.label4);
            this.panelTitleNameAdmin.Controls.Add(this.labelTitleControlDashboard);
            this.panelTitleNameAdmin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTitleNameAdmin.Location = new System.Drawing.Point(3, 3);
            this.panelTitleNameAdmin.Name = "panelTitleNameAdmin";
            this.panelTitleNameAdmin.Size = new System.Drawing.Size(300, 83);
            this.panelTitleNameAdmin.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("MV Boli", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(111, 50);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(160, 20);
            this.label4.TabIndex = 25;
            this.label4.Text = "Billing Management";
            // 
            // labelTitleControlDashboard
            // 
            this.labelTitleControlDashboard.AutoSize = true;
            this.labelTitleControlDashboard.Font = new System.Drawing.Font("Segoe UI Black", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitleControlDashboard.ForeColor = System.Drawing.Color.Yellow;
            this.labelTitleControlDashboard.Location = new System.Drawing.Point(8, 5);
            this.labelTitleControlDashboard.Name = "labelTitleControlDashboard";
            this.labelTitleControlDashboard.Size = new System.Drawing.Size(198, 45);
            this.labelTitleControlDashboard.TabIndex = 3;
            this.labelTitleControlDashboard.Text = "PoultryPro";
            this.labelTitleControlDashboard.Click += new System.EventHandler(this.labelTitleControlDashboard_Click);
            // 
            // panelTopLabelControl
            // 
            this.panelTopLabelControl.BackColor = System.Drawing.Color.Cornsilk;
            this.panelTopLabelControl.Controls.Add(this.label2);
            this.panelTopLabelControl.Controls.Add(this.label1);
            this.panelTopLabelControl.Controls.Add(this.labelAdminDevDashboard);
            this.panelTopLabelControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTopLabelControl.Location = new System.Drawing.Point(309, 3);
            this.panelTopLabelControl.Name = "panelTopLabelControl";
            this.panelTopLabelControl.Size = new System.Drawing.Size(1313, 83);
            this.panelTopLabelControl.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(700, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(329, 20);
            this.label2.TabIndex = 32;
            this.label2.Text = "*select one row for  Remove User/Product ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(700, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(288, 20);
            this.label1.TabIndex = 32;
            this.label1.Text = "*Double click on row for user Update ";
            // 
            // labelAdminDevDashboard
            // 
            this.labelAdminDevDashboard.AutoSize = true;
            this.labelAdminDevDashboard.Font = new System.Drawing.Font("Segoe UI", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAdminDevDashboard.Location = new System.Drawing.Point(29, 26);
            this.labelAdminDevDashboard.Name = "labelAdminDevDashboard";
            this.labelAdminDevDashboard.Size = new System.Drawing.Size(273, 45);
            this.labelAdminDevDashboard.TabIndex = 1;
            this.labelAdminDevDashboard.Text = "Welcome,Admin";
            // 
            // panelSlidebarControl
            // 
            this.panelSlidebarControl.BackColor = System.Drawing.Color.SandyBrown;
            this.panelSlidebarControl.Controls.Add(this.buttonLogoutControl);
            this.panelSlidebarControl.Controls.Add(this.pictureBox1);
            this.panelSlidebarControl.Controls.Add(this.btmSellReports);
            this.panelSlidebarControl.Controls.Add(this.btmAddSell);
            this.panelSlidebarControl.Controls.Add(this.btmManageProduct);
            this.panelSlidebarControl.Controls.Add(this.btmManageUser);
            this.panelSlidebarControl.Controls.Add(this.panel1);
            this.panelSlidebarControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelSlidebarControl.Location = new System.Drawing.Point(3, 92);
            this.panelSlidebarControl.Name = "panelSlidebarControl";
            this.panelSlidebarControl.Size = new System.Drawing.Size(300, 658);
            this.panelSlidebarControl.TabIndex = 4;
            // 
            // buttonLogoutControl
            // 
            this.buttonLogoutControl.BackColor = System.Drawing.Color.Red;
            this.buttonLogoutControl.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.buttonLogoutControl.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.buttonLogoutControl.Font = new System.Drawing.Font("Segoe UI Black", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonLogoutControl.ForeColor = System.Drawing.Color.White;
            this.buttonLogoutControl.Location = new System.Drawing.Point(9, 575);
            this.buttonLogoutControl.Name = "buttonLogoutControl";
            this.buttonLogoutControl.Size = new System.Drawing.Size(275, 58);
            this.buttonLogoutControl.TabIndex = 26;
            this.buttonLogoutControl.Text = "Logout";
            this.buttonLogoutControl.UseVisualStyleBackColor = false;
            this.buttonLogoutControl.Click += new System.EventHandler(this.buttonLogoutControl_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(30, 352);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(200, 200);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 25;
            this.pictureBox1.TabStop = false;
            // 
            // btmSellReports
            // 
            this.btmSellReports.BackColor = System.Drawing.Color.Transparent;
            this.btmSellReports.FlatAppearance.BorderSize = 0;
            this.btmSellReports.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal;
            this.btmSellReports.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.btmSellReports.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btmSellReports.Font = new System.Drawing.Font("Segoe UI Semibold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmSellReports.ForeColor = System.Drawing.Color.Black;
            this.btmSellReports.Image = ((System.Drawing.Image)(resources.GetObject("btmSellReports.Image")));
            this.btmSellReports.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btmSellReports.Location = new System.Drawing.Point(8, 273);
            this.btmSellReports.Name = "btmSellReports";
            this.btmSellReports.Padding = new System.Windows.Forms.Padding(11, 0, 0, 0);
            this.btmSellReports.Size = new System.Drawing.Size(286, 62);
            this.btmSellReports.TabIndex = 4;
            this.btmSellReports.Text = "Sell Report\'s";
            this.btmSellReports.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btmSellReports.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btmSellReports.UseVisualStyleBackColor = false;
            this.btmSellReports.Click += new System.EventHandler(this.btmSellReports_Click);
            // 
            // btmAddSell
            // 
            this.btmAddSell.BackColor = System.Drawing.Color.Transparent;
            this.btmAddSell.FlatAppearance.BorderSize = 0;
            this.btmAddSell.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal;
            this.btmAddSell.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.btmAddSell.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btmAddSell.Font = new System.Drawing.Font("Segoe UI Semibold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmAddSell.ForeColor = System.Drawing.Color.Black;
            this.btmAddSell.Image = ((System.Drawing.Image)(resources.GetObject("btmAddSell.Image")));
            this.btmAddSell.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btmAddSell.Location = new System.Drawing.Point(7, 206);
            this.btmAddSell.Name = "btmAddSell";
            this.btmAddSell.Padding = new System.Windows.Forms.Padding(11, 0, 0, 0);
            this.btmAddSell.Size = new System.Drawing.Size(286, 61);
            this.btmAddSell.TabIndex = 4;
            this.btmAddSell.Text = "Add Sell";
            this.btmAddSell.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btmAddSell.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btmAddSell.UseVisualStyleBackColor = false;
            this.btmAddSell.Click += new System.EventHandler(this.btmAddSell_Click);
            // 
            // btmManageProduct
            // 
            this.btmManageProduct.BackColor = System.Drawing.Color.Transparent;
            this.btmManageProduct.FlatAppearance.BorderSize = 0;
            this.btmManageProduct.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal;
            this.btmManageProduct.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.btmManageProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btmManageProduct.Font = new System.Drawing.Font("Segoe UI Semibold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmManageProduct.ForeColor = System.Drawing.Color.Black;
            this.btmManageProduct.Image = ((System.Drawing.Image)(resources.GetObject("btmManageProduct.Image")));
            this.btmManageProduct.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btmManageProduct.Location = new System.Drawing.Point(3, 139);
            this.btmManageProduct.Name = "btmManageProduct";
            this.btmManageProduct.Padding = new System.Windows.Forms.Padding(11, 0, 0, 0);
            this.btmManageProduct.Size = new System.Drawing.Size(298, 61);
            this.btmManageProduct.TabIndex = 4;
            this.btmManageProduct.Text = "Manage Product";
            this.btmManageProduct.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btmManageProduct.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btmManageProduct.UseVisualStyleBackColor = false;
            this.btmManageProduct.Click += new System.EventHandler(this.btmManageProduct_Click);
            // 
            // btmManageUser
            // 
            this.btmManageUser.BackColor = System.Drawing.Color.Transparent;
            this.btmManageUser.FlatAppearance.BorderSize = 0;
            this.btmManageUser.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal;
            this.btmManageUser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.btmManageUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btmManageUser.Font = new System.Drawing.Font("Segoe UI Semibold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmManageUser.ForeColor = System.Drawing.Color.Black;
            this.btmManageUser.Image = ((System.Drawing.Image)(resources.GetObject("btmManageUser.Image")));
            this.btmManageUser.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btmManageUser.Location = new System.Drawing.Point(9, 61);
            this.btmManageUser.Name = "btmManageUser";
            this.btmManageUser.Size = new System.Drawing.Size(275, 72);
            this.btmManageUser.TabIndex = 3;
            this.btmManageUser.Text = "Manage User\'s";
            this.btmManageUser.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btmManageUser.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btmManageUser.UseVisualStyleBackColor = false;
            this.btmManageUser.Click += new System.EventHandler(this.btmManageUser_Click);
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(343, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1050, 103);
            this.panel1.TabIndex = 1;
            // 
            // panelDisplayAdmin
            // 
            this.panelDisplayAdmin.BackColor = System.Drawing.Color.Transparent;
            this.panelDisplayAdmin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelDisplayAdmin.Controls.Add(this.formManageProducts1);
            this.panelDisplayAdmin.Controls.Add(this.userControlDefault);
            this.panelDisplayAdmin.Controls.Add(this.formManageUser_s1);
            this.panelDisplayAdmin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDisplayAdmin.Location = new System.Drawing.Point(309, 92);
            this.panelDisplayAdmin.Name = "panelDisplayAdmin";
            this.panelDisplayAdmin.Size = new System.Drawing.Size(1313, 658);
            this.panelDisplayAdmin.TabIndex = 3;
            // 
            // formManageProducts1
            // 
            dbConnections1.Ds = null;
            dbConnections1.Sda = null;
            dbConnections1.Sdr = null;
            dbConnections1.Sqlcom = null;
            this.formManageProducts1.DbConnections = dbConnections1;
            this.formManageProducts1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.formManageProducts1.Location = new System.Drawing.Point(0, 0);
            this.formManageProducts1.Name = "formManageProducts1";
            this.formManageProducts1.Size = new System.Drawing.Size(1311, 656);
            this.formManageProducts1.TabIndex = 2;
            // 
            // userControlDefault
            // 
            this.userControlDefault.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("userControlDefault.BackgroundImage")));
            this.userControlDefault.Dock = System.Windows.Forms.DockStyle.Fill;
            this.userControlDefault.Location = new System.Drawing.Point(0, 0);
            this.userControlDefault.Name = "userControlDefault";
            this.userControlDefault.Size = new System.Drawing.Size(1311, 656);
            this.userControlDefault.TabIndex = 1;
            // 
            // formManageUser_s1
            // 
            this.formManageUser_s1.DbConnections = null;
            this.formManageUser_s1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.formManageUser_s1.Location = new System.Drawing.Point(0, 0);
            this.formManageUser_s1.Name = "formManageUser_s1";
            this.formManageUser_s1.Size = new System.Drawing.Size(1311, 656);
            this.formManageUser_s1.TabIndex = 0;
            // 
            // admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1625, 753);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "admin";
            this.Text = "Admin";
            this.Load += new System.EventHandler(this.admin_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panelTitleNameAdmin.ResumeLayout(false);
            this.panelTitleNameAdmin.PerformLayout();
            this.panelTopLabelControl.ResumeLayout(false);
            this.panelTopLabelControl.PerformLayout();
            this.panelSlidebarControl.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelDisplayAdmin.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panelDisplayAdmin;
        private System.Windows.Forms.Panel panelTitleNameAdmin;
        private System.Windows.Forms.Label labelTitleControlDashboard;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panelSlidebarControl;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btmSellReports;
        private System.Windows.Forms.Button btmAddSell;
        private System.Windows.Forms.Button btmManageProduct;
        private System.Windows.Forms.Button btmManageUser;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelTopLabelControl;
        private System.Windows.Forms.Label labelAdminDevDashboard;
        private System.Windows.Forms.Button buttonLogoutControl;
        private FormManageUser_s formManageUser_s1;
        private UserControlDefaultcs userControlDefault;
        private FormManageProducts formManageProducts1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}