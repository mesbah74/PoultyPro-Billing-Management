﻿using PoultyPro_Billing_Management.DataBase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PoultyPro_Billing_Management.Gui
{
    public partial class FormManageUser_s : UserControl
    {
        public DbConnections DbConnections { get; set; }
        public FormManageUser_s()
        {
            InitializeComponent();
            //this.Load += new EventHandler(FormManageUser_Load);
        }



        //private void btmUserShowAll_Click(object sender, EventArgs e)
        //{
        //    string connectionString = "Data Source=LAPTOP-GKL05M5P\\SQLEXPRESS;Initial Catalog=\"PoultryPro – Farm & Billing Management\";Integrated Security=True;TrustServerCertificate=True";

        //    using (SqlConnection sqlcon = new SqlConnection(connectionString))
        //    {
        //        sqlcon.Open();

       
        //        SqlCommand sqlcom = new SqlCommand("SELECT * FROM admin;", sqlcon);

        //        SqlDataAdapter sda = new SqlDataAdapter(sqlcom);
        //        DataTable dt = new DataTable();
        //        sda.Fill(dt);

        //        dgvAdmin.DataSource = dt; 
        //        sqlcon.Close();
        //    }
        //}

        private void LoadAllUsers()
        {
            PopulateGridView("SELECT u.id, u.full_name, u.email, u.username, r.role_name as role_name, u.mobile, u.nid, u.address, u.created_date, u.is_active FROM users u LEFT JOIN role r ON u.role_id = r.id ORDER BY u.id");
        }

        internal void PopulateGridView(string sql = "SELECT u.id, u.full_name, u.email, u.username, r.role_name as role_name, u.mobile, u.nid, u.address, u.created_date, u.is_active FROM users u LEFT JOIN role r ON u.role_id = r.id ORDER BY u.id")
        {
            if (this.DbConnections == null)
            {
                MessageBox.Show("Database access object is not initialized.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            try
            {
                var ds = this.DbConnections.ExecuteQuery(sql);

                if (ds != null)
                {
                    this.dataGridView1.DataSource = ds.Tables[0];
                }
                else
                {
                    this.dataGridView1.DataSource = null;
                }
                this.dataGridView1.ClearSelection();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error populating grid: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        public void RefreshUserData()
        {
            LoadAllUsers();
        }

        private void FormManageUser_Load(object sender, EventArgs e)
        {
            //string connectionString = "Data Source=LAPTOP-GKL05M5P\\SQLEXPRESS;Initial Catalog=PoultryPro – Farm & Billing Management;Integrated Security=True;TrustServerCertificate=True;";

            //using (SqlConnection sqlcon = new SqlConnection(connectionString))
            //{
            //    sqlcon.Open();

            //    SqlCommand sqlcom = new SqlCommand("SELECT * FROM admin;", sqlcon);
            //    SqlDataAdapter sda = new SqlDataAdapter(sqlcom);
            //    DataTable dt = new DataTable();
            //    sda.Fill(dt);

            //    dgvAdmin.DataSource = dt;

            //    sqlcon.Close();

            //}
           
        }

        private void btmUserAddUser_Click(object sender, EventArgs e)
        {
            try
            {
                FormAddUser addUserForm = new FormAddUser(this.DbConnections, this);
                DialogResult result = addUserForm.ShowDialog();

                if (result == DialogResult.OK)
                {
                    LoadAllUsers();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error opening Add User form: " + ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btmUserShowAll_Click(object sender, EventArgs e)
        {
            txtSearch.Text = "";
            LoadAllUsers();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchName = txtSearch.Text.Trim();

            if (string.IsNullOrEmpty(searchName))
            {
                LoadAllUsers();
            }
            else
            {
                string sql = "SELECT u.id, u.full_name, u.email, u.username, r.role_name as role_name, u.mobile, u.nid, u.address, u.created_date, u.is_active FROM users u LEFT JOIN role r ON u.role_id = r.id WHERE u.full_name LIKE '%" + searchName.Replace("'", "''") + "%' ORDER BY u.id";
                PopulateGridView(sql);
            }
        }

        //private void txtSearchName_KeyDown(object sender, KeyEventArgs e)
        //{
        //    if (e.KeyCode == Keys.Enter)
        //    {
        //        btnSearch_Click(sender, e);
        //        e.Handled = true;
        //    }
        //}

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
               
                if (e.RowIndex < 0)
                {
                    return; 
                }

               
                if (e.RowIndex >= this.dataGridView1.Rows.Count)
                {
                    return; 
                }

               
                if (this.dataGridView1.Rows[e.RowIndex].Cells["id"].Value == null)
                {
                    MessageBox.Show("No data in selected row.", "Warning",
                                   MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

             
              int userId = Convert.ToInt32(this.dataGridView1.Rows[e.RowIndex].Cells["id"].Value);

               
                FormEditUser editUserForm = new FormEditUser(this.DbConnections, this, userId);
                DialogResult result = editUserForm.ShowDialog();

                if (result == DialogResult.OK)
                {
                    LoadAllUsers(); 
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error opening Edit User form: " + ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        

        private void btmUserRemove_Click(object sender, EventArgs e)
        {

            try
            {
                if (this.dataGridView1.SelectedRows.Count < 1)
                {
                    MessageBox.Show("Please select a row first to delete.", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }


                var id = this.dataGridView1.CurrentRow.Cells["Id"].Value.ToString();
                var fullName = this.dataGridView1.CurrentRow.Cells["full_name"].Value.ToString();

                var result = MessageBox.Show("Are you sure to delete data?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                if (result == DialogResult.No)
                    return;

                var sql = "delete from users where Id = '" + id + "';";
                var count = this.DbConnections.ExecuteDMLQuery(sql);

                if (count == 1)
                    MessageBox.Show(fullName.ToUpper() + " has been removed from the list");
                else
                    MessageBox.Show("Data hasn't been deleted from the list");

                this.LoadAllUsers();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Deleting user: " + ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClearSelection_Click(object sender, EventArgs e)
        {
            this.dataGridView1.ClearSelection();
            this.dataGridView1.DataSource = null;
            this.txtSearch.Clear();
            this.LoadAllUsers();
        }
    }
    }

