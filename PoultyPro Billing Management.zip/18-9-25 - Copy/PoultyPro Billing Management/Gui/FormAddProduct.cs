﻿using PoultyPro_Billing_Management.DataBase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PoultyPro_Billing_Management.Gui
{
    public partial class FormAddProduct : Form
    {

        public DbConnections DbConnections { get; set; }
        public FormManageProducts FormManageProducts { get; set; }
        public int SelectionRow { get; set; }
        private bool IsEditMode { get; set; }
        public FormAddProduct()
        {
            InitializeComponent();
        }
        public FormAddProduct(DbConnections dbConnections, FormManageProducts formManageProducts, int selectedRow) : this()
        {
            this.DbConnections = dbConnections;
            this.FormManageProducts = formManageProducts;
            this.SelectionRow = selectedRow;
            this.IsEditMode = selectedRow != -1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void FormAddProduct_Load(object sender, EventArgs e)
        {

            chkIsActive.Checked = true;
            //dtpCreatedDate.Value = DateTime.Now;
            //dtpCreatedDate.Enabled = false;

            ClearErrorHighlighting();
            ClearErrorMessages();

            if (IsEditMode)
            {
                lblTitle.Text = "Update Product";
                btnSave.Text = "Update Product";
                LoadProductData();
            }
            else
            {
                lblTitle.Text = "Add New Product";
                btnSave.Text = "Save Product";
                LoadNextProductId();
            }
        }

        private void LoadNextProductId()
        {
            if (this.DbConnections == null)
            {
                MessageBox.Show("Database access object is not initialized.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            try
            {
                string sql = "SELECT ISNULL(MAX(id), 0) + 1 FROM product;";
                var ds = this.DbConnections.ExecuteQuery(sql);

                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    var nextId = ds.Tables[0].Rows[0][0].ToString();
                    this.txtProductId.Text = nextId;
                    this.txtProductId.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error getting next product ID: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void LoadProductData()
        {
            if (this.DbConnections == null)
            {
                MessageBox.Show("Database access object is not initialized.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            try
            {
                string sql = "SELECT * FROM product WHERE id = @id;";
                string sqlWithParam = sql.Replace("@id", this.SelectionRow.ToString());
                var ds = this.DbConnections.ExecuteQuery(sqlWithParam);

                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    var row = ds.Tables[0].Rows[0];

                    this.txtProductId.Text = row["id"].ToString();
                    this.txtProductId.Enabled = false;
                    this.txtProductName.Text = row["name"].ToString();
                    this.txtQunatity.Text = row["quantity"].ToString();

                
                    this.txtCategory.Text = row["categoryName"].ToString();
                    this.txtPrice.Text = row["unit_price"].ToString();

                    if (DateTime.TryParse(row["created_date"].ToString(), out DateTime createdDate))
                        this.dtpDate.Value = createdDate;

                    this.chkIsActive.Checked = Convert.ToBoolean(row["is_active"]);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading product data: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

            private bool ValidateFields()
        {
            ClearErrorHighlighting();
            ClearErrorMessages();

            bool isValid = true;

            if (string.IsNullOrWhiteSpace(txtProductName.Text))
            {
                ShowError(txtProductName, lblNameError, "Product Name is required");
                isValid = false;
            }
            else if (txtProductName.Text.Length < 2 || txtProductName.Text.Length > 50)
            {
                ShowError(txtProductName, lblNameError, "Product Name must be between 2 and 50 characters");
                isValid = false;
            }

            if (string.IsNullOrWhiteSpace(txtQunatity.Text))
            {
                ShowError(txtQunatity, lblQuantityError, "Quantity is required");
                isValid = false;
            }
            else if (!int.TryParse(txtQunatity.Text, out int quantity) || quantity < 0)
            {
                ShowError(txtQunatity, lblQuantityError, "Quantity must be a non-negative whole number");
                isValid = false;
            }

            

            if (string.IsNullOrWhiteSpace(txtCategory.Text))
            {
                ShowError(txtCategory, lblCategoryError, "Category Name is required");
                isValid = false;
            }
            else if (txtCategory.Text.Length < 2 || txtCategory.Text.Length > 50)
            {
                ShowError(txtCategory, lblCategoryError, "Category Name must be between 2 and 50 characters");
                isValid = false;
            }

            if (string.IsNullOrWhiteSpace(txtPrice.Text))
            {
                ShowError(txtPrice, lblUnitPriceError, "Unit Price is required");
                isValid = false;
            }
            else if (!decimal.TryParse(txtPrice.Text, out decimal unitPrice) || unitPrice <= 0)
            {
                ShowError(txtPrice, lblUnitPriceError, "Unit Price must be a positive number");
                isValid = false;
            }

            return isValid;
        }

        private void ShowError(Control control, Label errorLabel, string message)
        {
            control.BackColor = Color.LightPink;
            errorLabel.Text = message;
            errorLabel.Visible = true;
        }

        private void ClearErrorHighlighting()
        {
            txtProductName.BackColor = Color.White;
            txtQunatity.BackColor = Color.White;
        
          
            txtCategory.BackColor = Color.White;
            txtPrice.BackColor = Color.White;
            dtpDate.BackColor = Color.White;
        }
        private void ClearErrorMessages()
        {
            lblNameError.Text = "";
            lblNameError.Visible = false;
            lblQuantityError.Text = "";
            lblQuantityError.Visible = false;
           
            lblCategoryError.Text = "";
            lblCategoryError.Visible = false;
            lblUnitPriceError.Text = "";
            lblUnitPriceError.Visible = false;
            lblCreatedError.Text = "";
            lblCreatedError.Visible = false;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (ValidateFields())
            {
                if (IsEditMode)
                    UpdateProduct();
                else
                    SaveProduct();
            }


        }

        private void UpdateProduct()
        {
            try
            {
                string name = txtProductName.Text.Replace("'", "''");
                int quantity = int.Parse(txtQunatity.Text);
               
                string categoryName = txtCategory.Text.Replace("'", "''");
                decimal unitPrice = decimal.Parse(txtPrice.Text);
               bool isActive = chkIsActive.Checked;
                int productId = int.Parse(txtProductId.Text);

                string sql = $@"UPDATE product SET 
    name = '{name}',
    quantity = {quantity},
    categoryName = '{categoryName}',
    unit_price = {unitPrice},
    is_active = {(isActive ? 1 : 0)}
    WHERE id = {productId}";


                int result = DbConnections.ExecuteDMLQuery(sql);

                if (result > 0)
                {
                    MessageBox.Show("Product updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                   FormManageProducts.PopulateGridView();
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Failed to update product. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Please ensure Quantity and Unit Price are valid numbers.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating product: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SaveProduct()
        {
            try
            {
                string name = txtProductName.Text.Replace("'", "''");
                int quantity = int.Parse(txtQunatity.Text);
              
                string categoryName = txtCategory.Text.Replace("'", "''");
                decimal unitPrice = decimal.Parse(txtPrice.Text);
                DateTime createdDate = dtpDate.Value;
                bool isActive = chkIsActive.Checked;

                string sql = $@"INSERT INTO product 
    (name, quantity, categoryName, unit_price, created_date, is_active)
    VALUES('{name}', {quantity}, '{categoryName}', {unitPrice}, '{createdDate.ToString("yyyy-MM-dd")}', {(isActive ? 1 : 0)})";


                int result = DbConnections.ExecuteDMLQuery(sql);

                if (result > 0)
                {
                    MessageBox.Show("Product added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    FormManageProducts.PopulateGridView();
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Failed to add product. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Please ensure Quantity and Unit Price are valid numbers.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving product: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

      
    }
}

